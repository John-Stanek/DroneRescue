#include "filter.h"

void Filter::Apply(std::vector<Image*> original, std::vector<Image*> filtered) {}