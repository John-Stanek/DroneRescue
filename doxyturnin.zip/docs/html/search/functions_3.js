var searchData=
[
  ['doublethresholdfilter_63',['DoubleThresholdFilter',['../classDoubleThresholdFilter.html#a0509c987eae92e4b94d63d2fbcef4819',1,'DoubleThresholdFilter']]]
];
