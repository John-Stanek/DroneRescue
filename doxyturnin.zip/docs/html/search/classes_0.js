var searchData=
[
  ['cannyedgedetectfilter_42',['CannyEdgeDetectFilter',['../classCannyEdgeDetectFilter.html',1,'']]],
  ['color_43',['Color',['../classColor.html',1,'']]]
];
