var searchData=
[
  ['saveas_78',['SaveAs',['../classImage.html#ad83156bf1431971a8e1f461019383e32',1,'Image']]],
  ['setalpha_79',['SetAlpha',['../classColor.html#a77f547e06436e60392413a978b76db13',1,'Color']]],
  ['setblue_80',['SetBlue',['../classColor.html#a769c95b5df56e248a22446c0b740c474',1,'Color']]],
  ['setgreen_81',['SetGreen',['../classColor.html#a85cdde2e94ef1eebc802d0403c7fb20b',1,'Color']]],
  ['setpixel_82',['SetPixel',['../classImage.html#a329a9835aa5b653b7e741ca2476c0da5',1,'Image']]],
  ['setred_83',['SetRed',['../classColor.html#a08135f1b358e2d13fa3c7e3664a52bdd',1,'Color']]],
  ['sobelfilter_84',['SobelFilter',['../classSobelFilter.html#ae46218b3594451a1b5fbdf0ebbd7c688',1,'SobelFilter']]]
];
