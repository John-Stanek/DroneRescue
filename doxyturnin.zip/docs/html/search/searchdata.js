var indexSectionsWithContent =
{
  0: "abcdfghimnorstw~",
  1: "cdfghimnstw",
  2: "nw",
  3: "abcdgiorst~",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

