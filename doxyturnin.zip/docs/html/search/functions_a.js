var searchData=
[
  ['_7egaussianblurfilter_86',['~GaussianBlurFilter',['../classGaussianBlurFilter.html#a371400ed538c678311cc950f8eaa5218',1,'GaussianBlurFilter']]],
  ['_7eimage_87',['~Image',['../classImage.html#a0294f63700543e11c0f0da85601c7ae5',1,'Image']]],
  ['_7esobelfilter_88',['~SobelFilter',['../classSobelFilter.html#afae76cfc4c1367bd6b26d3b53d2ebd98',1,'SobelFilter']]]
];
