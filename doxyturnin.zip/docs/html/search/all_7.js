var searchData=
[
  ['image_17',['Image',['../classImage.html',1,'Image'],['../classImage.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../classImage.html#afb0339b802ed560e69eb07358d30198f',1,'Image::Image(int width, int height)'],['../classImage.html#a9700f58efb58b13e23666f19c67d3839',1,'Image::Image(const char *filename)'],['../classImage.html#aa44ed77d00d96d2c878b050835f828c4',1,'Image::Image(const Image &amp;img)']]]
];
