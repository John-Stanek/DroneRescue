var searchData=
[
  ['red_25',['Red',['../classColor.html#ae212502d1420f4b935dad02b9b17131a',1,'Color']]]
];
