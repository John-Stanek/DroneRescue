var searchData=
[
  ['color_62',['Color',['../classColor.html#a9a742cbe9f9f4037f5d9f4e81a9b2428',1,'Color::Color()'],['../classColor.html#ac18ac1dbee9c4138544d1dc61cc3caea',1,'Color::Color(float red, float green, float blue, float alpha)']]]
];
