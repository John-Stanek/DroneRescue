var searchData=
[
  ['sharpenfilter_52',['SharpenFilter',['../classSharpenFilter.html',1,'']]],
  ['sobelfilter_53',['SobelFilter',['../classSobelFilter.html',1,'']]],
  ['stbi_5fio_5fcallbacks_54',['stbi_io_callbacks',['../structstbi__io__callbacks.html',1,'']]]
];
