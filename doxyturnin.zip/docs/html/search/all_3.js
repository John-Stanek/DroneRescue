var searchData=
[
  ['doublethresholdfilter_5',['DoubleThresholdFilter',['../classDoubleThresholdFilter.html',1,'DoubleThresholdFilter'],['../classDoubleThresholdFilter.html#a0509c987eae92e4b94d63d2fbcef4819',1,'DoubleThresholdFilter::DoubleThresholdFilter()']]]
];
