var searchData=
[
  ['search_20and_20rescue_20drone_26',['Search And Rescue Drone',['../index.html',1,'']]],
  ['saveas_27',['SaveAs',['../classImage.html#ad83156bf1431971a8e1f461019383e32',1,'Image']]],
  ['setalpha_28',['SetAlpha',['../classColor.html#a77f547e06436e60392413a978b76db13',1,'Color']]],
  ['setblue_29',['SetBlue',['../classColor.html#a769c95b5df56e248a22446c0b740c474',1,'Color']]],
  ['setgreen_30',['SetGreen',['../classColor.html#a85cdde2e94ef1eebc802d0403c7fb20b',1,'Color']]],
  ['setpixel_31',['SetPixel',['../classImage.html#a329a9835aa5b653b7e741ca2476c0da5',1,'Image']]],
  ['setred_32',['SetRed',['../classColor.html#a08135f1b358e2d13fa3c7e3664a52bdd',1,'Color']]],
  ['sharpenfilter_33',['SharpenFilter',['../classSharpenFilter.html',1,'']]],
  ['sobelfilter_34',['SobelFilter',['../classSobelFilter.html',1,'SobelFilter'],['../classSobelFilter.html#ae46218b3594451a1b5fbdf0ebbd7c688',1,'SobelFilter::SobelFilter()']]],
  ['stbi_5fio_5fcallbacks_35',['stbi_io_callbacks',['../structstbi__io__callbacks.html',1,'']]]
];
