var searchData=
[
  ['blue_2',['Blue',['../classColor.html#a9bba5de22a953eb924173eb1c207f667',1,'Color']]]
];
