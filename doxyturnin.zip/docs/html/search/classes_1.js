var searchData=
[
  ['doublethresholdfilter_44',['DoubleThresholdFilter',['../classDoubleThresholdFilter.html',1,'']]]
];
