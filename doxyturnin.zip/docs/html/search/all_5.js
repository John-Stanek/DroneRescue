var searchData=
[
  ['gaussianblurfilter_7',['GaussianBlurFilter',['../classGaussianBlurFilter.html',1,'GaussianBlurFilter'],['../classGaussianBlurFilter.html#a5b073291df50d87077650371c90af0f9',1,'GaussianBlurFilter::GaussianBlurFilter()'],['../classGaussianBlurFilter.html#ad9584fb6aebc6983839e34d693b6cc02',1,'GaussianBlurFilter::GaussianBlurFilter(float sigma, int size)']]],
  ['getarctan_8',['GetArcTan',['../classSobelFilter.html#aba48658b506c06024a72233cf1151d28',1,'SobelFilter']]],
  ['getcomponentnum_9',['GetComponentNum',['../classImage.html#a04e02c5aa54d26422bbaa777b08de4c9',1,'Image']]],
  ['getheight_10',['GetHeight',['../classImage.html#a4d6de643ee334ff52c85da9a62d9297d',1,'Image']]],
  ['gethypot_11',['GetHypot',['../classSobelFilter.html#adcbd8486cf4417a74e3cbe39151b7f3b',1,'SobelFilter']]],
  ['getpixel_12',['GetPixel',['../classImage.html#a7a154d7a3ed58baaeb73e1fdf9017afb',1,'Image']]],
  ['getwidth_13',['GetWidth',['../classImage.html#a4ab80d76fd124fd9de9b4fca8ae16186',1,'Image']]],
  ['green_14',['Green',['../classColor.html#a6fac5c8fc1822b01d2f5500ba906eb6e',1,'Color']]],
  ['greyscalefilter_15',['GreyScaleFilter',['../classGreyScaleFilter.html',1,'']]]
];
